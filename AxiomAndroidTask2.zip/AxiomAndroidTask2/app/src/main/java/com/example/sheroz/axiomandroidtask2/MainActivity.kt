package com.example.sheroz.axiomandroidtask2

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var userId : TextView = findViewById(R.id.userShowID)

        var userName : TextView = findViewById(R.id.tvNameUser)
        var userAge : TextView = findViewById(R.id.tvAgeUser)
        var userEmail : TextView = findViewById(R.id.tvEmailUser)

        var btnNext : Button = findViewById(R.id.btNext)
        var btnPrevious: Button = findViewById(R.id.btPrevious)

        var User0 : User = User("User Name", "00","Name@gmail.com")
        var User1 : User = User("Shehroz", "24","Shehroz@gmail.com")
        var User2 : User = User("Ali", "23","Ali@gmail.com")
        var User3 : User = User("Shezaib", "22","Shezaib@gmail.com")
        var User4 : User = User("Murtaza", "24","Murtaza@gmail.com")
        var User5 : User = User("Sheraz", "25","Sheraz@gmail.com")

        var userListArray :ArrayList<User> =  ArrayList()

        userListArray.add(User0)
        userListArray.add(User1)
        userListArray.add(User2)
        userListArray.add(User3)
        userListArray.add(User4)
        userListArray.add(User5)

        var count:Int =  0

        userId.setText("" + count)

        userName.setText(User0.name)
        userAge.setText(User0.age)
        userEmail.setText(User0.email)

        btnNext.setOnClickListener(){
            if (count+1 >= userListArray.size )
            {
                Toast.makeText(this, "No More Record, We Have $count User Records!!!",Toast.LENGTH_SHORT).show()
            }
            else
            {
                count++
                userId.setText("" + count)
                userName.setText(userListArray.get(count).name)
                userAge.setText(userListArray.get(count).age)
                userEmail.setText(userListArray.get(count).email)
            }
        }
        btnPrevious.setOnClickListener(){
            if (count-1 < 0 )
            {
                Toast.makeText(this,"No Previous Records,Move Forward!!!",Toast.LENGTH_SHORT).show()
            }
            else
            {
                count--
                userId.setText("" + count)
                userName.setText(userListArray.get(count).name)
                userAge.setText(userListArray.get(count).age)
                userEmail.setText(userListArray.get(count).email)
            }
        }
    }
}
open class User (var name : String,var age : String, var email : String) {}